package com.udacity.asteroidradar.main

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
}